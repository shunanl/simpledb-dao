package com.cogniance.simpledb.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

import com.cogniance.simpledb.model.SimpleDBEntity;
import com.cogniance.simpledb.util.SimpleDBObjectBuilder;
import com.xerox.amazonws.sdb.Domain;
import com.xerox.amazonws.sdb.Item;
import com.xerox.amazonws.sdb.ItemAttribute;
import com.xerox.amazonws.sdb.QueryWithAttributesResult;
import com.xerox.amazonws.sdb.SDBException;
import com.xerox.amazonws.sdb.SimpleDB;

/**
 * Extend this class to have basic support for SimpleDB DAO. Child classes should implement getters
 * for access and secret keys, and also for model class.
 * 
 * @author Andriy Gusyev
 */
public abstract class SimpleDBDAOSupport<T extends SimpleDBEntity<ID>, ID extends Serializable> {

    private static final String SELECT_COUNT_ALL = "select count(*) from %s";

    private static final String SELECT_COUNT_WHERE = "select count(*) from %s where %s";

    private static final String EMPTY_TOKEN = "";
    
    private static final Integer BATCH_SIZE = 250;

    private static SimpleDB sdb;

    protected abstract Class<T> getEntityClass();

    protected abstract String getAccessKey();

    protected abstract String getSecretKey();

    @SuppressWarnings("unchecked")
    protected Domain getDomain() throws SDBException {
        if (sdb == null) {
            sdb = new SimpleDB(getAccessKey(), getSecretKey());
        }
        Class clz = getEntityClass();
        String domainName;
        Entity annotation = (Entity) clz.getAnnotation(Entity.class);
        if (annotation != null) {
            domainName = annotation.name();
        } else {
            domainName = clz.getSimpleName();
        }
        return sdb.getDomain(domainName);
    }

    @SuppressWarnings("unchecked")
    public List<T> findAll() {
        try {
            List<T> list = new ArrayList<T>();
            Domain domain = getDomain();
            String token = EMPTY_TOKEN;
            if (token != null) {
                QueryWithAttributesResult result = domain.listItemsWithAttributes("", null, token.equals(EMPTY_TOKEN)
                        ? null : token, BATCH_SIZE);
                token = result.getNextToken();
                for (List<ItemAttribute> attrs : result.getItems().values()) {
                    T obj = (T) SimpleDBObjectBuilder.buildObject(getEntityClass(), attrs);
                    list.add(obj);
                }
            }
            return list;
        } catch (SDBException e) {
            throw new IllegalStateException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public T findById(ID id) {
        try {
            Domain domain = getDomain();
            Item item = domain.getItem(id.toString());
            T obj = (T) SimpleDBObjectBuilder.buildObject(getEntityClass(), item.getAttributes());
            return obj;
        } catch (SDBException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Returns number of items in domain
     * 
     * @return
     */
    public Integer countRows() {
        try {
            Domain domain = getDomain();
            String select = String.format(SELECT_COUNT_ALL, domain.getName());
            QueryWithAttributesResult result = domain.selectItems(select, null);
            for (List<ItemAttribute> list : result.getItems().values()) {
                if (list.size() > 0) {
                    ItemAttribute attr = list.get(0);
                    return Integer.parseInt(attr.getValue());
                }
            }
            return 0;
        } catch (SDBException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Returns number of items with condition
     * 
     * @param conditionQuery - part of the query after WHERE
     * @return
     */
    public Integer countRows(String conditionQuery) {
        try {
            Domain domain = getDomain();
            String select = String.format(SELECT_COUNT_WHERE, domain.getName(), conditionQuery);
            QueryWithAttributesResult result = domain.selectItems(select, null);
            for (List<ItemAttribute> list : result.getItems().values()) {
                if (list.size() > 0) {
                    ItemAttribute attr = list.get(0);
                    return Integer.parseInt(attr.getValue());
                }
            }
            return 0;
        } catch (SDBException e) {
            throw new IllegalStateException(e);
        }
    }
}
